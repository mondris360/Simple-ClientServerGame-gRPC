package com.mondris.soap.demo.Services;

import com.mondris.soap.demo.DTO.NumberDto;
import com.mondris.soap.demo.util.ApiResponse;
import com.mondris.soap.demo.util.Helper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class HttpUrlConnectionSoapDemo {
    // method to and two numbers
    public ResponseEntity<ApiResponse> addition(NumberDto numberDto)  throws Exception {
        return Helper.executeHttpUrlRequest(numberDto, "Add");
    }

    // method to multiply two numbers
    public ResponseEntity<ApiResponse> multiplication(NumberDto numberDto) throws Exception {
       return Helper.executeHttpUrlRequest(numberDto, "Multiply");
    }

    // method to divide a number
    public Object division(NumberDto numberDto) throws Exception {
        if (numberDto.getNumb2() == 0){
            return "You cannot divide a number by zero";
        } else {
            return Helper.executeHttpUrlRequest(numberDto, "Divide");
        }
    }

    // method to divide a number
    public ResponseEntity<ApiResponse> subtraction(NumberDto numberDto) throws Exception {

            return Helper.executeHttpUrlRequest(numberDto, "Subtract");
    }

}
