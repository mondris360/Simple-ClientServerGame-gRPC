package com.mondris.soap.demo.util;

import com.mondris.soap.demo.DTO.NumberDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.annotation.Resource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

@Slf4j
@Service
public class Helper {
    @Autowired
    private RestTemplate restTemplate;
    private static final String soapServiceUrl =  "http://www.dneonline.com/calculator.asmx";
    private ResponseEntity<ApiResponse> responseResponseEntity;
    // method to execute HttpUrlConnection Request
    public static ResponseEntity<ApiResponse> executeHttpUrlRequest(NumberDto number, String operator) {
        ApiResponse apiResponse =  new ApiResponse();
        String xmlReqPayloadStr = String.format("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                "  <soap:Body>\n" +
                "    <%s xmlns=\"http://tempuri.org/\">\n" +
                "      <intA>%d</intA>\n" +
                "      <intB>%d</intB>\n" +
                "    </%s>\n" +
                "  </soap:Body>\n" +
                "</soap:Envelope>", operator, number.getNumb1(), number.getNumb2(), operator);
        System.out.println(xmlReqPayloadStr);
        HttpURLConnection httpUrlConnection;
        String responseData =  "";

        try {
            // convert the reqPayload str to byte array
            byte[] reqPayloadToByte =  xmlReqPayloadStr.getBytes();

            // prepare the connection
            URL url =  new URL(soapServiceUrl);
            httpUrlConnection = (HttpURLConnection) url.openConnection();
            httpUrlConnection.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
            httpUrlConnection.setRequestProperty("Content-Length", String.valueOf(reqPayloadToByte.length));
            httpUrlConnection.setRequestProperty("SOAPAction", "http://tempuri.org/" + operator);
            httpUrlConnection.setRequestMethod("POST");
            // use the url connection to send output
            httpUrlConnection.setDoOutput(true);
            // use the url connection to read input
            httpUrlConnection.setDoInput(true);

            // get the connection output stream
            OutputStream outputStream =  httpUrlConnection.getOutputStream();
            // write the req payload to the output stream
            outputStream.write(reqPayloadToByte);
            outputStream.flush();

            int statusCode =  httpUrlConnection.getResponseCode();
            System.out.println("status code" +  statusCode);
            if(statusCode>= 200 && statusCode < 300) {
                InputStream inputStream =  httpUrlConnection.getInputStream();
                responseData =  readStream(inputStream, operator);
                apiResponse.setAnswer(responseData);
                apiResponse.setResponseStatus("Successful");
                apiResponse.setStatusCode(HttpStatus.OK.value());

            } else if (statusCode >= 300 && statusCode <500) {
                InputStream errorStream =  httpUrlConnection.getErrorStream();
                responseData =  readStream(errorStream, operator);
                apiResponse.setResponseStatus("Failed");
                apiResponse.setStatusCode(HttpStatus.BAD_REQUEST.value());
                apiResponse.setError(responseData);
            }
        } catch (MalformedURLException e) {
            log.warn(e.getMessage());
            apiResponse.setResponseStatus("Failed");
            apiResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            apiResponse.setError(e.getMessage());
//            throw new MalformedURLException(e.getMessage());
        } catch(IOException e) {
            log.info(e.getMessage());
            apiResponse.setResponseStatus("Failed");
            apiResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            apiResponse.setError(e.getMessage());
//            throw  new IOException(e.getMessage());
        } catch (Exception e){
            apiResponse.setResponseStatus("Failed");
            apiResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            apiResponse.setError(e.getMessage());
//            throw new Exception("Internal Server Error");
        }
        return new ResponseEntity<ApiResponse>(apiResponse, HttpStatus.valueOf(apiResponse.getStatusCode())) ;
    }


    // method to execute rest template  request
    public ResponseEntity<ApiResponse> executeRestTemplateReq(NumberDto number, String operator) throws Exception {
        // request payload xml
        String xmlReqPayloadStr = String.format("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                "  <soap:Body>\n" +
                "    <%s xmlns=\"http://tempuri.org/\">\n" +
                "      <intA>%d</intA>\n" +
                "      <intB>%d</intB>\n" +
                "    </%s>\n" +
                "  </soap:Body>\n" +
                "</soap:Envelope>", operator, number.getNumb1(), number.getNumb2(), operator);

        // prepare the rest template connection
        HttpHeaders httpHeaders =  new HttpHeaders();
        httpHeaders.setContentType(MediaType.TEXT_XML);
        // create the Request Entity
        HttpEntity<String> requestEntity =  new HttpEntity<String>(xmlReqPayloadStr, httpHeaders);
       HttpEntity<String> httpEntity =  new HttpEntity<String>(xmlReqPayloadStr, httpHeaders);
       ResponseEntity<String>  response =  restTemplate.exchange(soapServiceUrl, HttpMethod.POST, httpEntity, String.class);
       String filteredResponse =  filterAnswerFromXmlResponseStr(response.getBody(), operator);
       ApiResponse apiResponse = new ApiResponse();
       apiResponse.setError();
        return filterAnswerFromXmlResponseStr(response.getBody(), operator);
    }

    // method to read api response from input stream and filter the actual answer value
    private static String readStream(InputStream stream, String operator) throws Exception {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stream));
        StringBuilder responseData =  new StringBuilder();

        // read the response body from the buffer
        String line =  bufferedReader.readLine();
        while(line != null){
            responseData.append(line);
            // read the next line
            line =  bufferedReader.readLine();
        }
        return filterAnswerFromXmlResponseStr(responseData.toString(), operator);
    }

    // method to filter answer from xml response
    private  static String filterAnswerFromXmlResponseStr(String xmlResponseStr, String operator) throws Exception  {
        ResponseEntity<ApiResponse> apiResponseResponseEntity;
        String answer;
        try {
            DocumentBuilderFactory documentBuilderFactory =  DocumentBuilderFactory.newDefaultInstance();
            DocumentBuilder documentBuilder =  documentBuilderFactory.newDocumentBuilder();
            // read the xml response str
            InputSource inputSource =  new InputSource(new StringReader(xmlResponseStr));
            // converts the xml to document module of nodes
            final Document document = documentBuilder.parse(inputSource);
            //extract the node that contains the actual response value from the document object module
            NodeList nodeList =  document.getElementsByTagName(operator+ "Result");
            answer =  nodeList.item(0).getTextContent();
        }catch (ParserConfigurationException e) {
            log.info(e.getMessage());
            throw new ParserConfigurationException(e.getMessage());
        }catch (SAXException e) {
            log.info(e.getMessage());
            throw new SAXException(e.getMessage());
        }
        return answer;
    }
}
