package com.mondris.soap.demo.Controllers;

import com.mondris.soap.demo.DTO.NumberDto;
import com.mondris.soap.demo.Services.HttpUrlConnectionSoapDemo;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
public class HttpUrlController {
    @Resource
    private HttpUrlConnectionSoapDemo httpUrlConnectionSoapDemo;

    // route for addition
    @PostMapping("/httpUrlConnection/add")
    public String addNumbers(@RequestBody NumberDto number) throws Exception {
        return httpUrlConnectionSoapDemo.addition(number);
    }

    // route for multiplication
    @PostMapping("/httpUrlConnection/multiply")
    public String multiplyNumbers(@RequestBody NumberDto numberDto) throws Exception {
        return httpUrlConnectionSoapDemo.multiplication(numberDto);
    }
    // route for division
    @PostMapping("/httpUrlConnection/divide")
    public String divideNumber(@RequestBody NumberDto numberDto) throws Exception {
        return  httpUrlConnectionSoapDemo.division(numberDto);
    }

    // route for subtraction
    @PostMapping("/httpUrlConnection/subtraction")
    public String subtraction(@RequestBody NumberDto numberDto) throws Exception {
        return  httpUrlConnectionSoapDemo.subtraction(numberDto);
    }
}
