package com.mondris.webservice.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Configuration
public class SoapConfig {
// method to convert xml to java class and vice versa
    @Bean
    public Jaxb2Marshaller marshaller(){
        Jaxb2Marshaller marshaller =  new Jaxb2Marshaller();
        // specify the package to scan for binding classes that will be used
        //for the conversion
        marshaller.setPackagesToScan("com.bindingclasses.webservice");
        return  marshaller;
    }


}
