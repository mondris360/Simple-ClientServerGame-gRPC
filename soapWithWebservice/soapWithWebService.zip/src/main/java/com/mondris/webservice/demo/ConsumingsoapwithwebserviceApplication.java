package com.mondris.webservice.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumingsoapwithwebserviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConsumingsoapwithwebserviceApplication.class, args);
    }

}
