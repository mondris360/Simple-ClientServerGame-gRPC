package com.mondris.webservice.demo.Controller;

import com.bindingclasses.webservice.*;
import com.mondris.webservice.demo.Service.WebServiceDemo;
import com.mondris.webservice.demo.util.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
public class Calculator {

    @Resource
    private WebServiceDemo webServiceDemo;

    // route for addition
    @PostMapping("/webservice/add")
    public ResponseEntity<ApiResponse> addNumbers(@RequestBody Add request) throws Exception {
        return webServiceDemo.addTwoNumbers(request);
    }

//    // route for multiplication
    @PostMapping("/webservice/multiply")
    public ResponseEntity<ApiResponse> multiplyNumbers(@RequestBody Multiply request) throws Exception {
        return webServiceDemo.multiplyTwoNumbers(request);
    }

    // route for division
    @PostMapping("/webservice/divide")
    public ResponseEntity<ApiResponse> divideNumbers(@RequestBody Divide request) throws Exception {
        return webServiceDemo.divideTwoNumbers(request);
    }

    // route for subtraction
    @PostMapping("/webservice/subtract")
    public ResponseEntity<ApiResponse> divideNumbers(@RequestBody Subtract request) throws Exception {
        return webServiceDemo.subtraction(request);
    }
}
