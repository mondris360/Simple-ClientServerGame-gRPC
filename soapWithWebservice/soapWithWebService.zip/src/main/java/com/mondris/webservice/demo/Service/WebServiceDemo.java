package com.mondris.webservice.demo.Service;

import com.bindingclasses.webservice.*;
import com.mondris.webservice.demo.util.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import javax.annotation.Resource;

@Service
@Slf4j
public class WebServiceDemo {
    @Resource
    private Jaxb2Marshaller marshaller;
    private static final String soapServiceUrl =  "http://www.dneonline.com/calculator.asmx";
    @Resource
    private ApiResponse apiResponse;


    public ResponseEntity<ApiResponse> addTwoNumbers(Add request)  {
        return executeRequest(request, "http://tempuri.org/Add");
    }
    //method to subtract one number from another
    public ResponseEntity<ApiResponse> subtraction(Subtract request){
        return  executeRequest(request, "http://tempuri.org/Subtract");
    }

    // method to multiply two numbers
    public ResponseEntity<ApiResponse> multiplyTwoNumbers(Multiply request){

        return executeRequest(request,  "http://tempuri.org/Multiply");
    }

    // method to divide two numbers
    public ResponseEntity<ApiResponse> divideTwoNumbers(Divide request){
        return executeRequest(request, "http://tempuri.org/Divide");
    }

    // execute api request
    private  ResponseEntity<ApiResponse> executeRequest(Object request, String soapAction){
        Object responsePayLoad = null;
        ResponseEntity<ApiResponse> preparedResponse;
        WebServiceTemplate webServiceTemplate = new WebServiceTemplate(marshaller);
        try {
            responsePayLoad = webServiceTemplate.marshalSendAndReceive(soapServiceUrl, request, new SoapActionCallback(soapAction));
            apiResponse.setAnswer(responsePayLoad);
            apiResponse.setResponseStatus("Successful");
            apiResponse.setStatusCode(HttpStatus.OK.value());
            preparedResponse = new ResponseEntity<ApiResponse>(apiResponse, HttpStatus.valueOf(apiResponse.getStatusCode()));
        } catch (Exception e){
            log.info(e.getMessage());
            apiResponse.setResponseStatus("Failed");
            apiResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            apiResponse.setError(e.getMessage());
            preparedResponse =  new ResponseEntity<ApiResponse>(apiResponse, HttpStatus.valueOf(apiResponse.getStatusCode()));
        }
        return  preparedResponse;
    }

}
