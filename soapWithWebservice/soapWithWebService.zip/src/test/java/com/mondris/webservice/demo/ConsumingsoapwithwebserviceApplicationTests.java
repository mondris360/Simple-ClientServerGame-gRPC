package com.mondris.webservice.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumingsoapwithwebserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
